<?php

$user_name = $_GET['user-name'];
$user_pass = $_GET['user-pass'];
?>

<h1>My Site</h1>
<p>Your username is <?=$user_name?></p>
<p>Your password is <?=$user_pass?></p>
