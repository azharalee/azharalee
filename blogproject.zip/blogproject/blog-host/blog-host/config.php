<?php
// DATABASE SERVER
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'bloghost');
?>